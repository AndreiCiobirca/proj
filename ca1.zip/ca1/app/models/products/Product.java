package models.products;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Employee extends Model {
    
        
        @Id
        private Long id;
        @Constraints.Required
        private String name;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="Employees")
        public List<department> categories;
        @Constraints.Required
        private String email; 
        

        public static final Finder<Long, Employee> find = new Finder<>(Employee.class);
       
        private List<Long> catSelect = new ArrayList<Long>();

        public static final List<Employee> findAll() { 
            
            return Employee.find.all();
}
  
       
        public Employee() {
        }
    
        
        public Employee(Long id, String name, String email, int stock, double price) {
            this.id = id;
            this.name = name;
            this.email = email;
        }
    
      
        public Long getId() {
            return id;
        }
        public void setId(Long id) {
            this.id = id;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }

        public String getemail() { 
            return email; 
        } 
        public void setemail(String email) { 
            this.email = email; 
        } 
    
        public List<Long> getCatSelect(){
            return catSelect;
        }
        public void setCatSelect(List<Long> catSelect){
            this.catSelect = catSelect;
        }
    }
    
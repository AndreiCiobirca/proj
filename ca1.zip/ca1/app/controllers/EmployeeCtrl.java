package controllers;

import play.mvc.*;
import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;


import models.users.*;
import models.Employees.*;
import views.html.*;




public class EmployeeCtrl extends Controller {

    
    private FormFactory formFactory;
    private Environment e;
    
    @Inject
    public EmployeeCtrl(FormFactory f,Environment env) {
        this.formFactory = f;
        this.e = env;
        }
    
    @Transactional
	public User getCurrentUser() {
		User u = User.getLoggedIn(session().get("email"));
		return u;
	}
    public Result index() {
        return redirect(routes.EmployeeCtrl.listEmployees(0));
    }

    
    @Transactional
    public Result listEmployees(Long cat) {
       
        List<department> categories = department.findAll();
        		
        List<Employee> Employees = new ArrayList<Employee>();
    
        if (cat == 0) {
            
            Employees = Employee.findAll();
        }
        else {
            
            Employees = department.find.ref(cat).getEmployees();
        }
        
        return ok(listEmployees.render(Employees,department, getCurrentUser(),e));
    }
    public Result EmployeeDetails(Long id) {
        Employee p;

        p = Employee.find.byId(id);

        return ok(Employee.render(p,User.getLoggedIn(session().get("email")),e));
    }
    
}
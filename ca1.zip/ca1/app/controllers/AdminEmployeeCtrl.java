package controllers;

import controllers.security.*;

import play.mvc.*;
import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;


import models.users.*;
import models.Employees.*;
import views.html.EmployeeAdmin.*;

import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;


@Security.Authenticated(Secured.class)

@With(CheckIfAdmin.class)


public class AdminEmployeeCtrl extends Controller {

    
    private FormFactory formFactory;
    private Environment e;
    
    @Inject
    public AdminEmployeeCtrl(FormFactory f,Environment env) {
        this.formFactory = f;
        this.e = env;
    }
       
	private User getCurrentUser() {
		User u = User.getLoggedIn(session().get("email"));
		return u;
	}
    public Result index() {
        return redirect(controllers.routes.AdminEmployeeCtrl.listEmployees(0));
    }
    
    @Transactionalustomer
    public Result listEmployees(Long cat) {
        
        List<department> categories = department.findAll();
       			
        List<Employee> Employees = new ArrayList<Employee>();
    
        if (cat == 0) {
            
            Employees = Employee.findAll();
        }else {
            Employees = department.find.ref(cat).Employee();
        }

        
        return ok(listEmployees.render(Employees, categories, getCurrentUser(),e));
    }

    @Transactional
    public Result addEmployee() {
        Form<Employee> addEmployeeForm = formFactory.form(Employee.class);
        return ok(addEmployee.render(addEmployeeForm, getCurrentUser()));
    }
    @Transactional
    public Result addEmployeeSubmit() {
        Employee newEmployee;
        String saveImageMsg;
        Form<Employee> newEmployeeForm = formFactory.form(Employee.class).bindFromRequest();

        if (newEmployeeForm.hasErrors()) {
            return badRequest(addEmployee.render(newEmployeeForm, 
            getCurrentUser()));
        }
        else {
             newEmployee = newEmployeeForm.get();

        
                
                newEmployee.save();
                                
                    for (Long cat : newEmployee.getCatSelect()) {
                        newEmployee.categories.add(department.find.byId(cat));
                    }
                newEmployee.update();
        }
        MultipartFormData data = request().body().asMultipartFormData();
        

        

        flash("success", "Employee " + newEmployee.getName() + " has been created/updated " );

        return redirect(controllers.routes.AdminEmployeeCtrl.index());
    }
    
   
    @Transactional
    public Result deleteEmployee(Long id) {
        Employee.find.ref(id).delete();

        flash("success", "Employee has been removed");
        
        return redirect(routes.AdminEmployeeCtrl.index());
    }


    @Transactional
    public Result updateEmployee(Long id) {
        Employee p;
        Form<Employee> EmployeeForm;

        try {
            p = Employee.find.byId(id);
            EmployeeForm = formFactory.form(Employee.class).fill(p);
        } 
        catch (Exception ex) {
            return badRequest("error");
        }
        return ok(updateEmployee.render(id, EmployeeForm,getCurrentUser()));
    }

    @Transactional
   public Result updateEmployeeSubmit(Long id) {
    
        
                
                Form<Employee> updateEmployeeForm = formFactory.form(Employee.class).bindFromRequest();
        
                
                if (updateEmployeeForm.hasErrors()) {
                    
                    return badRequest(updateEmployee.render(id,updateEmployeeForm, getCurrentUser()));
                } else {
                    
                    Employee p = updateEmployeeForm.get();
                    p.setId(id);                    
                    
                    
                   
                    List<department> newCats = new ArrayList<department>();
                    for (Long cat : p.getCatSelect()) {
                        newCats.add(department.find.byId(cat));
                    }
                    p.categories = newCats;
                    
                    p.update();
        
                    MultipartFormData data = request().body().asMultipartFormData();
                    
        
                    =
        
                    flash("success", "Employee " + p.getName() + " has been created/updated ");
                    
                    
                    return redirect(controllers.routes.AdminEmployeeCtrl.index());
                }
            }

            

   

    
}
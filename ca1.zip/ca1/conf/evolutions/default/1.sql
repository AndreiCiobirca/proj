# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table department (
  id                            bigint auto_increment not null,
  department_name                          varchar(255),
  constraint pk_department primary key (id)
);



create table employee (
  emp_id                            bigint auto_increment not null,
  name                          varchar(255),
  email                         varchar(255),
  constraint pk_employee primary key (id)
);

create table user (
  role                          varchar(255),
  email                         varchar(255) not null,
  name                          varchar(255),
  password                      varchar(255),
  department                    varchar(255),
  street1                       varchar(255),
  street2                       varchar(255),
  town                          varchar(255),
  post_code                     varchar(255),
  credit_card                   varchar(255),
  constraint pk_user primary key (email)
);


# --- !Downs


drop table if exists department;

drop table if exists employee;

drop table if exists user;


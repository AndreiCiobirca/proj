# --- !Ups
delete from user;

insert into user (email,name,password,role) values ( 'lee123@hotmail.com', 'Lee Byrne', 'password', 'admin' );

insert into user (email,name,password,role) values ( 'Johndaly@hotmail.com', 'John Daly', 'password', 'manager' );

insert into user (email,name,password,role) values ( 'Charlieconroy@yahoo.com', 'Charlie Conroy', 'password', 'customer' );
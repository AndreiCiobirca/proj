# --- Sample dataset
 
# --- !Ups
 
delete from employee;
delete from department;

insert into department (id,department_name) values ( 1,'Marketing' );
insert into department (id,department_name) values ( 2,'Finance' );
insert into department (id,department_name) values ( 3,'Accounting' );
insert into department (id,department_name) values ( 4,'IT' );
insert into department (id,department_name) values ( 5,'Human Resources' );

 
insert into employee (emp_id,name,email) values ( 1,'Andrei Ciobirca','mancitylad97@gmail.com');
insert into employee (emp_id,name,email) values ( 2,'Colm Dunne','colm_dunne1@outlook.com' );
insert into employee (emp_id,name,email) values ( 3,'Sebastian Ichim','sebastian@live.ie');
insert into employee (emp_id,name,email) values ( 4,'Andrei Iancu','andreiiancu@yahoo.com');
insert into employee (emp_id,name,email) values ( 5,'Azees Fetuga','Azeesfe2ga@hot,ail.com');
 

